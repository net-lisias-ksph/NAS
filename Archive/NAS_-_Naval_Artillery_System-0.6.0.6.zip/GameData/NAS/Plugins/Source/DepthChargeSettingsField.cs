﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AntiSubmarineWeapon
{
    [AttributeUsage(AttributeTargets.Field)]
    class DepthChargeSettingsField : Attribute
    {
        public DepthChargeSettingsField()
        {

        }
    }
}
