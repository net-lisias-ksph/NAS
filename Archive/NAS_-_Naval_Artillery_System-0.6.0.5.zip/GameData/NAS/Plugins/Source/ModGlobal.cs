﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AntiSubmarineWeapon
{
    internal static class ModGlobal
    {
        internal static bool drawSettingsWindow = false;
        internal static bool loadedSceneIsOn
        {
            get
            {
                return HighLogic.LoadedSceneIsFlight || HighLogic.LoadedSceneIsEditor;
            }
        }
    }
}
