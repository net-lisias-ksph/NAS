﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using AntiSubmarineWeapon;
//using UnityEngine;

//namespace AntiSubmarineWeapon
//{
//    class ModuleTO : PartModule
//    {
//        [KSPField]
//        public float cruiseDepth = 0f;

//        [KSPField]
//        public Vector3 maxRotate = Vector3.zero;

//        [KSPField]
//        public Vector3 maxTorque = Vector3.zero;

//        [KSPField]
//        public Vector3 pidAngleInfo = Vector3.zero;

//        [KSPField]
//        public Vector3 pidTorqueInfo = Vector3.zero;

//        PIDSystem PID = new PIDSystem();
//        PIDSystem PID2 = new PIDSystem();
        
//        private Rigidbody partRigidbodyValue;
//        private Rigidbody partRigidbody
//        {
//            get
//            {
//                if (!partRigidbodyValue)
//                    partRigidbodyValue = part.GetComponent<Rigidbody>();
//                return partRigidbodyValue;
//            }
//        }
//        public override void OnStart(PartModule.StartState state)
//        {
//            base.OnStart(state);
//            PID.PIDDataWrite(maxRotate.z,pidAngleInfo.x,pidAngleInfo.y,pidAngleInfo.z);
//            PID2.PIDDataWrite(maxRotate.z, pidTorqueInfo.x, pidTorqueInfo.y, pidTorqueInfo.z);
//        }
//        public override void OnFixedUpdate()
//        {
//            base.OnFixedUpdate();
//            if ((vessel.mainBody.GetAltitude(vessel.GetWorldPos3D())) < 0)
//            {
//                float angle = PID.PIDControl(cruiseDepth, (float)(vessel.mainBody.GetAltitude(vessel.GetWorldPos3D())), TimeWarp.fixedDeltaTime);
//                //partRigidbody.angularVelocity = new Vector3(0, PID2.PIDControl(0.785f, k, kI, kD, angle, (float)(((Vector3.Angle(transform.right, vessel.transform.position)) - 45) * (Math.PI / 180)), TimeWarp.fixedDeltaTime), 0);
//                float Torque = PID2.PIDControl(angle, (90 - Vector3.Angle(this.part.transform.forward, FlightGlobals.getUpAxis(this.part.transform.position))), TimeWarp.fixedDeltaTime);
//                Vector3 horizonPitchAxis = Vector3.Cross(FlightGlobals.getUpAxis(transform.position), transform.forward).normalized;
//                partRigidbody.AddTorque(-horizonPitchAxis*Torque);
//            }
//            Debug.Log(90-Vector3.Angle(this.part.transform.forward,FlightGlobals.getUpAxis(this.part.transform.position)));
//        }

//    }
//}
